console.log("========================================");
console.log("   Halo Chain - Single Address Mining");
console.log("========================================");
var MINER_ADDRESS = "0xda21a3d4477f3efe9a80b94476550cd7685ad3db";
var BOOTNODE = "enode://ed8d6bd76ab9a5619f59fa54d40ae859fee684bb6beaeb9425c2d6f270f6a77b4eb7b2d57d826a849f7c343a174bb42ff3b000a053678e395bcadf6b04fe1321@51.20.84.193:30303";
var miningStarted = false;
var initialSyncComplete = false;
var zeroPeerStartTime = null;

function checkAndAddBootnode(peerCount) {
  if (peerCount === 0) {
    if (zeroPeerStartTime === null) {
      zeroPeerStartTime = Date.now();
      console.log("[PEER] No peers, monitoring...");
    } else if (Date.now() - zeroPeerStartTime > 5000) {
      console.log("[BOOTNODE] Adding bootnode...");
      try {
        admin.addPeer(BOOTNODE);
        console.log("[SUCCESS] Bootnode added");
      } catch (e) {
        console.log("[ERROR] " + e);
      }
      zeroPeerStartTime = null;
    }
  } else {
    zeroPeerStartTime = null;
  }
}

function checkNetworkSync() {
  try {
    var myBlock = eth.blockNumber;
    var peers = net.peerCount;
    var syncStatus = eth.syncing;
    var highestPeerBlock = myBlock;
    if (syncStatus && syncStatus.highestBlock) {
      highestPeerBlock = syncStatus.highestBlock;
    }
    var blockDiff = Math.abs(highestPeerBlock - myBlock);
    console.log("[SYNC] Block: " + myBlock + ", Peer: " + highestPeerBlock + ", Diff: " + blockDiff + ", Peers: " + peers);
    if (!initialSyncComplete) {
      if (syncStatus === false && myBlock > 100) {
        console.log("[SYNC] Initial sync complete");
        initialSyncComplete = true;
      } else if (syncStatus && syncStatus.highestBlock && syncStatus.currentBlock) {
        if (blockDiff <= 3 && myBlock > 100) {
          console.log("[SYNC] Initial sync complete");
          initialSyncComplete = true;
        } else {
          var progress = (syncStatus.currentBlock / syncStatus.highestBlock * 100).toFixed(2);
          console.log("[SYNCING] " + progress + "% complete");
          return false;
        }
      } else {
        console.log("[WAITING] Syncing from peers...");
        return false;
      }
    }
    if (myBlock > highestPeerBlock + 5) {
      console.log("[WARNING] " + (myBlock - highestPeerBlock) + " blocks AHEAD - STOPPING");
      if (miningStarted) {
        miner.stop();
        miningStarted = false;
      }
      return false;
    }
    if (blockDiff > 3) {
      console.log("[SYNCING] Behind by " + blockDiff + " blocks");
      if (miningStarted) {
        miner.stop();
        miningStarted = false;
      }
      return false;
    }
    return true;
  } catch(e) {
    console.log("[ERROR] Sync check: " + e);
    return false;
  }
}

function startMining() {
  console.log("\n==========================================");
  console.log("   STARTING MINING");
  console.log("==========================================");
  console.log("[ADDRESS] " + MINER_ADDRESS);
  try {
    miner.setEtherbase(MINER_ADDRESS);
    miner.start(1);
    miningStarted = true;
    console.log("[SUCCESS] Mining started at block " + eth.blockNumber);
    console.log("==========================================");
    return true;
  } catch(e) {
    console.log("[ERROR] " + e);
    return false;
  }
}

function mainLoop() {
  var peerCount = net.peerCount;
  checkAndAddBootnode(peerCount);
  if (peerCount < 1) {
    if (miningStarted) {
      console.log("[STOPPING] No peers");
      miner.stop();
      miningStarted = false;
    }
    return;
  }
  if (!initialSyncComplete) {
    console.log("[WAITING] Waiting for sync...");
    checkNetworkSync();
    return;
  }
  var isNetworkSynced = checkNetworkSync();
  if (isNetworkSynced && !miningStarted) {
    startMining();
  } else if (!isNetworkSynced && miningStarted) {
    console.log("[PAUSING] Sync issue");
    miner.stop();
    miningStarted = false;
  }
}

console.log("[INFO] Starting monitor...");
console.log("[BOOTNODE] Adding bootnode...");
try {
  admin.addPeer(BOOTNODE);
  console.log("[SUCCESS] Bootnode added");
} catch (e) {
  console.log("[WARNING] " + e);
}
mainLoop();
setInterval(mainLoop, 5000);
console.log("[INFO] Monitor active (5s interval)");
