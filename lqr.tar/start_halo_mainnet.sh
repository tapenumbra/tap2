#!/bin/bash
cd ~/halo

# === Конфигурация ===
DATA_DIR="$HOME/halo/halo-data"
GENESIS_FILE="$HOME/halo/halo_genesis.json"
GETH_BIN="$HOME/halo/halo-geth"
MINER_ADDRESS="0x9dc153e17bee1fbfe1a25e233b403aec045d2a9a"
BOOTNODE="enode://ed8d6bd76ab9a5619f59fa54d40ae859fee684bb6beaeb9425c2d6f270f6a77b4eb7b2d57d826a849f7c343a174bb42ff3b000a053678e395bcadf6b04fe1321@51.20.84.193:30303"

# === Проверки ===
if [ ! -f "$GENESIS_FILE" ]; then
  echo "[❌] Не найден genesis-файл: $GENESIS_FILE"
  exit 1
fi

if [ ! -d "$DATA_DIR/geth" ]; then
  echo "[⚙️] Инициализация новой сети HALO..."
  "$GETH_BIN" --datadir "$DATA_DIR" init "$GENESIS_FILE"
fi

echo "========================================"
echo "     🚀 Halo Mainnet Node Launcher"
echo "========================================"
echo "  📦 DataDir: $DATA_DIR"
echo "  💎 Miner: $MINER_ADDRESS"
echo "  🧩 NetworkID: 12000"
echo "  🌐 Bootnode: $BOOTNODE"
echo "========================================"
sleep 2

# === Запуск узла ===
exec "$GETH_BIN" \
  --datadir "$DATA_DIR" \
  --networkid 12000 \
  --syncmode full \
  --gcmode archive \
  --http \
  --http.addr "0.0.0.0" \
  --http.port 8545 \
  --http.api "eth,net,web3,debug,trace,txpool,miner,admin,personal" \
  --http.corsdomain "*" \
  --http.vhosts "*" \
  --ws \
  --ws.addr "0.0.0.0" \
  --ws.port 8546 \
  --ws.api "eth,net,web3,debug,trace,txpool,miner,admin,personal" \
  --ws.origins "*" \
  --bootnodes "$BOOTNODE" \
  --port 30303 \
  --maxpeers 50 \
  --mine \
  --miner.threads 1 \
  --miner.etherbase "$MINER_ADDRESS" \
  --allow-insecure-unlock \
  --verbosity 3
